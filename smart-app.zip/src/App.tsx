import { Layout } from './components';

export const App = () => {
  return <Layout />;
};
