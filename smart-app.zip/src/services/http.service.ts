import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

export class HttpService {
  constructor(
    public baseUrl = process.env.SERVICE_URL,
    // public baseUrl = 'https://jsonplaceholder.typicode.com',
    public fetchingService = axios
  ) {
    this.baseUrl = baseUrl;
    this.fetchingService = fetchingService;
  }

  private getFullApiUrl(url: string | undefined): string {
    return `${this.baseUrl}/${url}`;
  }

  private sanitizeConfig(
    config: AxiosRequestConfig
  ): Omit<AxiosRequestConfig, 'url' | 'data'> {
    const { url: _url, data: _data, ...configWithoutUrlAndData } = config;
    return configWithoutUrlAndData;
  }

  public get<T>(config: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    console.log('SERVICE_URL:', this.baseUrl);
    return this.fetchingService.get(
      this.getFullApiUrl(config.url),
      this.sanitizeConfig(config)
    );
  }
}
