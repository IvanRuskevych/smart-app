export const API_KEYS = {
  USERS: 'users',
};
