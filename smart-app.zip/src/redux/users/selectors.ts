import { RootState } from '../store';

export const usersSelector = (state: RootState) => state.users.users;
