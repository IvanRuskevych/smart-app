import { css } from '@emotion/css';

export const containerStyle = css`
  padding: 10px;
  border-radius: 5px;
  background-color: var(--background-secondary);
`;
